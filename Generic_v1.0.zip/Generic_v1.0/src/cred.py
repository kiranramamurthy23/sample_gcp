import os
import openai

# Chat Model
openai_credentials_chat = {
    "OPENAI_API_TYPE": "azure",
    "OPENAI_API_VERSION": "2023-07-01-preview",
    "OPENAI_API_BASE": '', # Please fill
    "OPENAI_API_KEY": "", # Please fill
    "DEPLOYMENT_NAME": "generator-model-turbo",
    "MODEL_NAME": "gpt-3.5-turbo"
    }


# Embedding Model
openai_credentials_embed = {
        "OPENAI_API_TYPE": "azure",
        "OPENAI_API_VERSION": "2022-12-01",
        "OPENAI_API_BASE": '',# Please fill
        "OPENAI_API_KEY": "",# Please fill
        "DEPLOYMENT_NAME": "embedding-modeL",
        "MODEL_NAME": "text-embedding-ada-002"
        }


def get_gpt_model(model):
    if model == 'chat':
        # Setting Environment
        os.environ["OPENAI_API_TYPE"]       = openai_credentials_chat["OPENAI_API_TYPE"]
        os.environ["OPENAI_API_VERSION"]    = openai_credentials_chat["OPENAI_API_VERSION"]
        os.environ["OPENAI_API_BASE"]       = openai_credentials_chat["OPENAI_API_BASE"]
        os.environ["OPENAI_API_KEY"]        = openai_credentials_chat["OPENAI_API_KEY"]
        return openai_credentials_chat["DEPLOYMENT_NAME"]
    elif model == 'embed':
        # Setting Environment
        os.environ["OPENAI_API_TYPE"]       = openai_credentials_embed["OPENAI_API_TYPE"]
        os.environ["OPENAI_API_VERSION"]    = openai_credentials_embed["OPENAI_API_VERSION"]
        os.environ["OPENAI_API_BASE"]       = openai_credentials_embed["OPENAI_API_BASE"]
        os.environ["OPENAI_API_KEY"]        = openai_credentials_embed["OPENAI_API_KEY"]
        return openai_credentials_embed["DEPLOYMENT_NAME"]
    
