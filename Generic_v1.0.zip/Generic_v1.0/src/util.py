from src.cred import *
import openai
import time
import datetime
import streamlit as st
import pickle
import os
import openai
import re
import random
from langchain.document_loaders import PyPDFLoader
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.document_loaders import DirectoryLoader
from langchain.document_loaders import TextLoader
from langchain.text_splitter import TokenTextSplitter

from langchain.vectorstores import FAISS

from langchain.chains import ConversationalRetrievalChain
from langchain.prompts import PromptTemplate
from langchain.chains.question_answering import load_qa_chain

from streamlit_mic_recorder import mic_recorder,speech_to_text


# Azure GPT
class auto_chat:
    def write_log(self,text, file):
        f = open(file, 'a')           # 'a' will append to an existing file if it exists
        f.write("{}\n".format(text))  # write the text to the logfile and move to next line
        return
    

    def get_gpt_response(self,query,user):
        if query.lower() in ['hi','hello','Yea','helo','hii']:
            return "Hello I'm Lara, how may I help you?"
        elif query.lower() in ['thanks','thank you','thank u','good']:
            return "You're most welcome"
        else:
            # Vector DB
            with open('files/db.pkl', 'rb') as f:
                db = pickle.load(f)
            
            # # Template Of Prompt
            
            CONDENSE_QUESTION_PROMPT = PromptTemplate.from_template("""Given the following conversation and a follow up question,
            rephrase the follow up question to be a standalone question.
            Chat History:
            {chat_history}
            Follow Up Input: {question}
            Standalone question:""")

            qa = ConversationalRetrievalChain.from_llm(llm=AzureChatOpenAI(deployment_name=get_gpt_model('chat')), # , temperature=0.7
                                                    retriever=db.as_retriever(search_kwargs={"k": 7}),
                                                    condense_question_prompt=CONDENSE_QUESTION_PROMPT,
                                                    return_source_documents=True,
                                                    verbose=False)

            try:
                chat_history = []
                rules = "Truthfully answer the question only from the given conversation and if question is not related to given conversation, Please mention 'Out of context'"
                gpt_response = qa({"question":rules + query, "chat_history": chat_history})
                
                citation = re.findall(r"metadata={'source': 'files\\\\(.*?)'}", str(gpt_response))
                citation = ",".join(list(set(citation))[:2])
                gpt_response    = gpt_response["answer"]
                
                if "out of context" in gpt_response.lower():
                    pass
                else:
                    gpt_response = gpt_response +"\n **Citations**: "+ citation
                return gpt_response
            except Exception as e:
                error           = 'Error occurred while using Azure OpenAI GPT Model'
                st.error(e)
                return e


    def chat_initiate(self,user):
        if "messages" not in st.session_state:
            st.session_state.messages = []

        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])             
        
        #TTS
        # text_tts = None
        _,c1 = st.columns([0.9,0.1])
        with c1:
            text_tts=speech_to_text(language='en',start_prompt="🎙️Mic",use_container_width=False,just_once=True,key='STT')
        
        if prompt := st.chat_input("What is up?"):
            st.session_state.messages.append({"role": "user", "content": prompt})
            with st.chat_message("user"):
                st.markdown(prompt)
                
            with st.chat_message("assistant",avatar="🤖"):
                message_placeholder = st.empty()
                full_response = ""
                gpt_response = self.get_gpt_response(prompt,user)

                for chunk in gpt_response.split():
                    full_response += chunk + " "
                    time.sleep(0.05)
                    # Add a blinking cursor to simulate typing
                    message_placeholder.markdown(full_response + "▌")
                
                message_placeholder.markdown(full_response)
                
            st.session_state.messages.append({"role": "assistant", "content": full_response})
        elif text_tts:
            st.session_state.messages.append({"role": "user", "content": text_tts})
            with st.chat_message("user"):
                st.markdown(text_tts)
            with st.chat_message("assistant",avatar="🤖"):
                message_placeholder = st.empty()
                full_response = ""
                gpt_response = self.get_gpt_response(text_tts,user)
                for chunk in gpt_response.split():
                    full_response += chunk + " "
                    time.sleep(0.05)
                    # Add a blinking cursor to simulate typing
                    message_placeholder.markdown(full_response + "▌")
                message_placeholder.markdown(full_response)
                st.session_state.messages.append({"role": "assistant", "content": full_response})
                gpt_response = None

class train_chat:       
    def read_pdf(self,pdf_file):
        try:
            with open("files/"+ pdf_file.name , mode='wb') as w:
                w.write(pdf_file.getvalue())

            # Load the book
            loader = PyPDFLoader("files/"+ pdf_file.name )
            pages = loader.load()

            # Combine the pages, and replace the tabs with spaces
            text = ""
            for page in pages:
                text += page.page_content
                
            text = text.replace('\t', ' ')
            text  = re.sub(r'[^\x00-\x7F]+'," ",text)
            # text = re.sub(r'\/uni0\w+', '', text)
            text = re.sub(r'\s*/uni00\w*\s*', '', text)
            
            with open("files/" + os.path.splitext(pdf_file.name)[0]+ ".txt", 'w') as txt_file: #, encoding='utf-8'
                txt_file.write(text)
        except Exception as e:
            st.error(e)
            st.error("PDF as permission issues, Please use OCR instead")


    def store_embeddings(self,doc,option):
        with st.spinner('Please Wait Vector DB Creation In progress...'):
            
            # PDF To Text
            if option == 'PDF':
                for i in doc:
                    self.read_pdf(i)
            else:
                # st.write(doc.name)
                for i in doc:
                    with open("files/"+ i.name , mode='wb') as w:
                        w.write(i.getvalue())
            
            # Load Documents
            loader = DirectoryLoader('files/', glob="*.txt", loader_cls=TextLoader)

            documents = loader.load()
            text_splitter = TokenTextSplitter(chunk_size=900, chunk_overlap=100)
            docs = text_splitter.split_documents(documents)
            
            # Azure Credentials
            embeddings = OpenAIEmbeddings(deployment=get_gpt_model("embed"), chunk_size=1)
            
            # Vector storage
            db = FAISS.from_documents(documents=docs, embedding=embeddings)

            # store the embeddings
            with open('files/db.pkl', 'wb') as f:
                pickle.dump(db, f)
            
            st.success("**Vector DB created successfully. Please proceed to chat**")