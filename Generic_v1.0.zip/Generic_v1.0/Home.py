import streamlit as st
# from PIL import Image
# from src.cred import *
from src.util import *
import streamlit.components.v1 as components
# import base64



################### Login helper functions ###########################################################
# clear DB
def clear_db():
    folder_path = 'files/'
    try:
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
                # print(f"Deleted: {file_path}")
        st.warning("All files deleted successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")

#app definition
def logout():
    """function to logout out of application."""
    st.session_state['authentication_status'] = None
    st.session_state['access_level'] = None

def login():
    """Function for user login."""
    #check if user exists in database
    if (len(username) > 0) and (len(password) > 0):
        if (username == 'Roy') and (password == 'admin123'):
            st.session_state['access_level'] = 'internal'
        elif (username == 'Steve') and (password == 'admin123'):
            st.session_state['access_level'] = 'external'
    
    #set the session state accordingly
    if st.session_state['access_level'] is not None:
        st.session_state['authentication_status'] = True
        st.session_state['username'] = username
        st.session_state['role'] = st.session_state['access_level']
    elif (st.session_state['access_level'] is None) and ((username is not None) and (password is not None)):
        st.session_state['authentication_status'] = False
        st.session_state['access_level'] = None
    else:
        st.session_state['authentication_status'] = None
        st.session_state['access_level'] = None


######################### main script#####################################################
st.set_page_config(layout='wide',page_title="Chatbot")

c1, c2,c3 = st.columns([0.3, 0.4, 0.3])
with c2:
    #check the authentication status/ Declaration of session variables
    if "authentication_status" not in st.session_state:
        st.session_state['authentication_status'] = None
    if "access_level" not in st.session_state:
        st.session_state['access_level'] = None       

    #check authentication status
    if st.session_state['authentication_status'] == False:
        # dsm_logo = Image.open("logo.PNG")
        # st.image(dsm_logo,width=425)
        st.title("Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        st.button("Login", on_click=login)
        st.error('Username/password is incorrect')

    elif st.session_state['authentication_status'] == None:
        # dsm_logo = Image.open("logo.PNG")
        # st.image(dsm_logo,width=425)
        st.title("Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        st.button("Login", on_click=login)
        st.warning('Please enter your username and password')

    elif st.session_state['authentication_status']:
        # image = Image.open(r'./img/user.jpg')
        # st.sidebar.image(image,width=50)
        # c1, c2,c3 = st.columns([0.2, 0.6, 0.2])
        # with c2:
        # st.sidebar.write("## Logged in successfully")
        st.sidebar.markdown("User : **{}**".format(str(st.session_state['username'])))
        if st.session_state['access_level'] == 'internal':
            st.sidebar.markdown("Role : **Data Scientist**")
        else:
            st.sidebar.markdown("Role: **Data Engineer**")
        st.sidebar.button("Logout", on_click=logout)
        st.sidebar.button("Reset DB", on_click=clear_db)


        #hide header and footer
        hide_streamlit_style = """<style>
                        #MainMenu {height: hidden;}
                        footer {visibility: hidden;}
                        header {visibility: hidden;}
                        </style>"""
        st.markdown(hide_streamlit_style, unsafe_allow_html=True)

        # # Remove Margins  #padding-left: 10rem;padding-bottom: 5rem;padding-top: 5rem;
        st.markdown("""<style>
                    .block-container {
                        padding-right: 10rem;
                    }</style>""", unsafe_allow_html=True)

if st.session_state['access_level'] is not None:
    # _, c1,_ = st.columns([0.05, 0.9, 0.05])
    # with c2:
    st.title("Upload your files here")
    docs = st.file_uploader('',accept_multiple_files=True,key = 1)
    
    _, c1,_ = st.columns([0.3, 0.4, 0.3])
    with c1:
        # Choose option
        option = st.selectbox('Please choose pdf to text option:',('PDF', 'TEXT'))
    
    _, c2,_ = st.columns([0.45, 0.45, 0.1])
    st.write("")
    st.write("")
    st.write("")
    st.write("")
    with c2:
        btn1 = st.button("Submit",key=2)
            
    if btn1:
        train = train_chat()
        train.store_embeddings(docs,option)