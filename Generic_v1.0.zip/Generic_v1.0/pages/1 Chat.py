from src.cred import *
from src.util import *

if st.session_state['access_level'] is not None:
    st.title("Ask Your Queries")
    chat = auto_chat()
    chat.chat_initiate(st.session_state['username'])
else:
    st.title("Login/Vector DB Failure. Please try again")
