import streamlit as st
from dataclasses import dataclass
import streamlit.components.v1 as components
from typing import Literal
import os
from PIL import Image
from streamlit_mic_recorder import mic_recorder,speech_to_text
from datetime import datetime as dt
import openai
from src.cred import *
import sqlite3
import pandas as pd
import azure.cognitiveservices.speech as speechsdk
import io
import base64
import re


st.set_page_config(layout='wide',page_title="Document Bot")

hide_streamlit_style = """
<style>
MainMenu {height: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}
</style>

"""
st.markdown(hide_streamlit_style, unsafe_allow_html=True)

######################################################################################
@dataclass
class Message:
    """Class for keeping track of a chat message."""
    origin: Literal["human", "ai"]
    message: str

def text2speech_en(text):
    # Create a speech configuration object
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)

    # Set the voice name and output format
    speech_config.speech_synthesis_voice_name = "en-US-JennyNeural" # You can change the voice name
    speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3)

    # Create an audio configuration object for saving the output to a file
    audio_output_file = "files/output.wav" # You can change the file name and extension
    audio_config = speechsdk.audio.AudioConfig(filename=audio_output_file)

    # Create a speech synthesizer object
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

    # Synthesize the text to speech and save the output to the file
    result = speech_synthesizer.speak_text_async(text).get()
    audio_data = result.audio_data

    # Convert the audio data to a bytes-like object
    audio_bytes = io.BytesIO(audio_data)
    
    audio_base64 = base64.b64encode(audio_data).decode('utf-8')
    audio_tag = f'<audio autoplay="true" src="data:audio/wav;base64,{audio_base64}">'
    st.markdown(audio_tag, unsafe_allow_html=True)
    
    
def remove_chars_before_select(sentence):
    select_index = sentence.find('SELECT')

    if select_index != -1:
        result = sentence[select_index:]
        return result
    else:
        # 'SELECT' not found in the sentence
        return sentence

def gpt_response_sql_doc(input_text):
    if input_text.lower() in ['hi','hello','Yea','helo']:
        return ("Hello I'm Lara, how may I help you?",None)
    elif input_text.lower() in ['thanks','thank you','thank u','good']:
        return ("You're most welcome",None)
    else:
        read_csv = pd.read_csv('files/data_incident.csv')
        with open("files/Data_Demo.txt", encoding='utf8') as f:
            read_txt = f.read()

        # Part -1
        prompt = """Please regard the following data:\n {}.
        Consider SQL table name as "incident_details". 
        For questions about date range. hardcode the right date and mention the where clause accordingly.
        Also, Strictly Write only the correct SQL query for following questions asked: {}""".format(read_csv, input_text)

        request = openai.ChatCompletion.create(
            engine='generator-model-turbo',
            messages=[
                {"role": "user", "content": prompt},
            ]
        )
        result = request['choices'][0]['message']['content']
        # print(result)
        if 'SELECT' in result.split():
            result = remove_chars_before_select(result)
            # st.write(result)
            # print('*'*80)
        
            # Now we will read from the database and convert it into a DataFrame
            try:
                conn = sqlite3.connect('kr_database.db')
                df_from_sqlite = pd.read_sql(result, conn)
                conn.close()
                # print(df_from_sqlite)
                # print('#'*80)
            
                # Part -2
                prompt = """For the given question '{}'. 
                Consider '{}' as the output coming from database running the correct SQL query. 
                Please strictly rephrase the SQL output into human readable sentence""".format(input_text,df_from_sqlite)
                request = openai.ChatCompletion.create(
                    engine='generator-model-turbo',
                    messages=[
                        {"role": "user", "content": prompt},
                    ]
                )
                result_text = request['choices'][0]['message']['content']
                # print(result)
                # print('#'*80)
                return (result_text,result)
            except:
                return ('The above SQL did not execute properly',result)
        else:
            del result
            # Part -2
            prompt = """Please regard the following data:\n {0}.
            Honestly answer follow up questions from above data. 
            Incase couldn't find the answer, Mention 'Out of Context' for following question asked: {1}""".format(read_txt, input_text)
            request = openai.ChatCompletion.create(
                engine='generator-model-turbo',
                messages=[
                    {"role": "user", "content": prompt},
                ]
            )
            result = request['choices'][0]['message']['content']
            return (result,["www.bayer.com/en/bayer/"
                            "https://www.macrotrends.net/stocks/charts/BAYRY/bayer/revenue",
                            "https://www.statista.com/statistics/263787/revenues-of-bayers-top-pharmaceutical-products/",
                            "https://www.bayer.com/media/en-us/bayer-significant-growth-in-sales-and-earnings/"
                            ])

def gpt_response_table(query):
    prompt = """
            You are a smart AI assistant.Please convert the given data into neat tabular format only: {0}""".format(query)
            #Incase couldn't do it, Mention 'No Charts To Display' for following data
    request = openai.ChatCompletion.create(
        engine='generator-model-turbo',
        messages=[
            {"role": "user", "content": prompt},
        ]
    )
    result = request['choices'][0]['message']['content']
    st.session_state.numeric = result

def llm_message(user_input):
    if user_input.lower() in ["hi","hello","howdy","how are you","hey"]:
        return "How are you ?"
    else:
        return "LLM will answer soon with this questions..!"
    

def load_css():
    with open("static/styles.css", "r") as f:
        css = f"<style>{f.read()}</style>"
        st.markdown(css, unsafe_allow_html=True)


def initialize_session_state():
    if "history" not in st.session_state:
        st.session_state.history = []
    if "response" not in st.session_state:
        st.session_state.response = []
    if "speech" not in st.session_state:
        st.session_state.speech = False
    if "numeric" not in st.session_state:
        st.session_state.numeric = []

def detect_numbers(sentence):
    # use the findall function with a pattern to extract digits
    numbers = re.findall(r'\d+', sentence)
    # return the list of numbers as integers
    return [int(n) for n in numbers]

def on_call_back():
    human_prompt = st.session_state.human_prompt
    llm_response,extra = gpt_response_sql_doc(human_prompt)
    if st.session_state.speech:
        text2speech_en(llm_response)
    st.session_state.history.append(
        Message("human",human_prompt)
        )
    
    st.session_state.history.append(
        Message("ai",llm_response)
        )
    if extra:
        st.session_state.response=extra
    else:
        st.session_state.response=[]
    if len(detect_numbers(llm_response))>0:
        gpt_response_table(llm_response)
        
# callback
def callback():
    if st.session_state.my_stt_output:
        output,extra = gpt_response_sql_doc(st.session_state.my_stt_output)
        st.session_state.history.append(Message("human",st.session_state.my_stt_output))
        st.session_state.history.append(Message("ai",output))
        if st.session_state.speech:
            text2speech_en(output)
        with chat_placeholder:
            history_list = st.session_state.history.copy()
            history_list = history_list[::-1][:2]
            history_list.reverse()
            # st.write(history_list[::-1][:2])
            for chat in history_list:
                if chat.origin=="ai":
                    img_path = "app/static/bot.png"
                else:
                    img_path = "app/static/user.png"
                div = f"""
                <div class="chat-row {'' if chat.origin=="human" else 'row-reverse'}">
                    <div><img class="chat-icon" src={img_path} width=32 height=32></div>
                    <div class="chat-bubble
                    {'ai-bubble' if chat.origin=="ai" else 'human-bubble'}">
                    &#8203;{chat.message}
                    </div>
                </div>
                """
                st.markdown(div, unsafe_allow_html=True)
        if extra:
            st.session_state.response=extra
        else:
            st.session_state.response=[]
        if len(detect_numbers(output))>0:
            gpt_response_table(output)

######################################################################################
load_css()
initialize_session_state()

cols = st.columns((0.3,0.38,0.32))

with cols[0]:
    col1_img_path = "app/static/sample_4.png"
    div = f"""

    <img class="col_1_img" src={col1_img_path}>

        """
    st.markdown(div, unsafe_allow_html=True)


with cols[1]:
        
        col2_img_path = "app/static/col2_img.png"
        div = f"""

        <img class="col_2_img" src={col2_img_path}>

        """
        st.markdown(div, unsafe_allow_html=True)
        
chat_placeholder = cols[1].container(border=True,height=550)

with chat_placeholder:
    history_list = st.session_state.history.copy()
    history_list2 = history_list[::-1][:2]
    history_list2.reverse()
    history_list = history_list[:-2]
    history_list = history_list + history_list2
    for chat in history_list:
        if chat.origin=="ai":
            img_path = "app/static/bot.png"
        else:
            img_path = "app/static/user.png"
        div = f"""
        <div class="chat-row {'' if chat.origin=="ai" else 'row-reverse'}">
            <div><img class="chat-icon" src={img_path} width=32 height=32></div>
            <div class="chat-bubble
            {'ai-bubble' if chat.origin=="ai" else 'human-bubble'}">
            &#8203;{chat.message}
            </div>
        </div>
        """
        st.markdown(div, unsafe_allow_html=True)

with cols[1]:
    cols_txt_mic = st.columns((0.85,0.15))
    with cols_txt_mic[0]:
        st.text_input(
                "Chat",
                value="",
                label_visibility="collapsed",
                key="human_prompt",on_change=on_call_back,
                help="Enter your Query"
            )
    with cols_txt_mic[1]:
        text_tts=speech_to_text(language='en',start_prompt="🎙️Mic",use_container_width=True,just_once=True,key='my_stt',callback=callback)

with cols[2]:
    sub_col_1 = st.container(height=180)
    sub_col_2 = st.container(height=235)
    sub_col_3 = st.container(height=240)
    with sub_col_1:
        tab1, tab2, tab3 = st.tabs(["Applications", "Chat Settings", "Team Requests"])
        with tab1:
            my_apps_img = "app/static/my_apps.png"
            div = f"""

            <img class="col_3_img1" src={my_apps_img}>

            """
            st.markdown(div, unsafe_allow_html=True)
        with tab2:
            # st.markdown("<p style='text-align:center;font-weight:bold;border-radius: 5px;background-color:lightblue;'>No Pending Actions..!</p>",unsafe_allow_html=True)
            rd = st.radio("",["🗣️","🔇"],index=None,)
            if rd == '🗣️':
                st.session_state.speech = True
            else:
                st.session_state.speech = False
        with tab3:
            st.write("")
            st.write("")
            st.markdown("<p style='text-align:center;font-weight:bold;border-radius: 5px;background-color:lightblue;'>No Requests..!</p>",unsafe_allow_html=True)
            # st.markdown("<p style='text-align:center;font-weight:bold;border-radius: 5px;background-color:#FFD580;'>No Requests..!</p>",unsafe_allow_html=True)
    
    if st.session_state.response == []:
        with sub_col_2:
            st.write("##### Notifications")
            with st.expander("You have 3 notifications"):
                # st.markdown("<p style='text-align:center;font-weight:bold;border-radius: 5px;background-color:lightblue;'>You have 3 notifications!!</p>",unsafe_allow_html=True)
                st.error("ITSM Tickets have been assigned against your name")
                st.info("Kindly fill your timesheet for this week")
                st.success("Your travel request has been approved by the manager")
        with sub_col_3:
            date_today = dt.today()
            date_format = date_today.strftime("%B %Y, %d")
            st.write("##### Upcoming Meetings - ")
            with st.expander("You have 2 meetings - "):
                st.write("")
                date_string = f"""
                <div style='text-align:center;border-radius: 8px;background-color:lightgreen'>

                <div style='border-style: dashed;text-align:center;border-radius: 8px;background-color:white'>
                <h8 style='text-align:center;font-weight:bold;border-radius: 5px'> Virtual iMotivate Session with Neha : </h8>
                <h8 style='text-align:center;font-weight:bold;border-radius: 5px'>{date_format}</h8>
                <h8 style='text-align:center;font-weight:bold;border-radius: 5px'> 02:30 PM - 03:30 PM IST</h8>
                </div>
                
                <div style='border-style: dashed;text-align:center;border-radius: 8px;background-color:white'>
                <h8 style='text-align:center;font-weight:bold;border-radius: 5px'> SNOW Digital Requirements : {date_format}</h8><br>
                <h8 style='text-align:center;font-weight:bold;border-radius: 5px'> 10:30 AM - 11:30 AM IST</h8>
                </div>
                </div>
                """
                st.markdown(date_string,unsafe_allow_html=True)
    else:
        with sub_col_2:
            st.write("##### References")
            try:
                st.session_state.response.split()
                st.write(st.session_state.response)
            except:
                for i in st.session_state.response:
                    st.write(i)
        with sub_col_3:
            st.write("##### Charts")
            # if st.session_state.numeric:
            st.write(st.session_state.numeric)          



