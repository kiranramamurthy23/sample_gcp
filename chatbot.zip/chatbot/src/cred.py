import os
import openai

# Set the OpenAI API key, base URL, type, and version
openai.api_key = 'c558662f30d94030b494a6e2549417ca'
openai.api_base = 'https://gpt-policy-bot.openai.azure.com/'
openai.api_type = 'azure'
openai.api_version = '2023-07-01-preview'

# Azure Speech Credentials
speech_key, service_region = "b0f3b648613345f2859a2ba1890dd4df", "eastus"